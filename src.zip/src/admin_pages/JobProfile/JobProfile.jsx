import React from 'react'

function JobProfile() {
  return (
    <div>
      <h1>job profile</h1>
    </div>
  )
}

export default JobProfile
