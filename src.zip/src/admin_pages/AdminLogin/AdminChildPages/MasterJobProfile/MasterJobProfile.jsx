import React from 'react'

function MasterJobProfile() {
  return (
    <div>
      <p>hello Job Profile hello Job Profile hello Job Profile </p>
    </div>
  )
}

export default MasterJobProfile
