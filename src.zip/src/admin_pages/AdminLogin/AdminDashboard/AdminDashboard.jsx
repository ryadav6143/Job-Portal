import React from "react";
import SideBar from "../SideBar/SideBar";
import "./AdminDashboard.css";

function AdminDashboard() {
  return (
    <>
      <SideBar></SideBar>
    </>
  );
}

export default AdminDashboard;
