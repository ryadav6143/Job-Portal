import React from "react";
import UserHeader from "./UserHeader/UserHeader";
import "./UserDashboard.css";


function UserDashboard() {
  return (
    <>
      <UserHeader></UserHeader>
    </>
  );
}

export default UserDashboard;
