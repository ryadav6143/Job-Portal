import React from "react";
import CandidateSidebar from "../CandidateSidebar/CandidateSidebar";
import "./CandidateDashboard.css";

function CandidateDashboard() {
  return (
    <>
      <CandidateSidebar></CandidateSidebar>
    </>
  );
}

export default CandidateDashboard;
